package Lesson12;

public class Test10 {
	public static void main(String[] args) {

		int salary = 300;

		if (salary < 200) {
			System.out.println("salary is too low ");
		} else if (salary < 400) {
			System.out.println("salary is avarage ");
		} else if (salary < 600) {
			System.out.println("salary is good ");
		} else {
			System.out.println("salary is super ");
		}
	}
}
