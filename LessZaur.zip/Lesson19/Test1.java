package Lesson19;

public class Test1 {

	public static void main(String[] args) {

		System.out.println("0 - element of array arg =" + args[0]);
		System.out.println("Lenght array args " + args.length);

	}
}
